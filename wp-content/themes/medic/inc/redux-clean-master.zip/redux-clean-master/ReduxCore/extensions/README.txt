This directory is a placeholder for Redux Framework extensions.
